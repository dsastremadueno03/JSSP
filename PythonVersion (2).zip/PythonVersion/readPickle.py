import pickle # Read pickled objects
import os # Access the path
import glob # Get the general files (*)
import matplotlib.pyplot as plt # Show the result plots
from individual import Individual # Individual class
from schedule import Schedule # Schedule class

# Unpickle individuals
def unpickleInd():
    bestInd = [] # List of individuals
    i = 1
    # Stores the individuals in the folder "results"
    path = glob.glob(os.path.join(r"results/pickle", "*.pkl"))
    for file in path:
        with open(file, 'rb') as pickled:
            bestInd = pickle.load(pickled)
            for ind in bestInd:
                print("Individual", i)
                print(ind)
                i += 1
    return bestInd
    
    
# Unpickles, as a plot, the evolution of a specific iteration
def plotEvol(a, b):
    path = os.path.join(r"results/graphic/", f"plot_{a}_result_{b}.pkl")
    data = []
    with open(path, 'rb') as pickled:
        data = pickle.load(pickled)

    N_GENERATIONS = len(data) # Number of generations
    axisValue = []
    for i in range(N_GENERATIONS):
        axisValue.append(int(i+1)) # Generation number
        
    fitnessTimePlot = [] # Tardiness
    fitnessEnergyPlot = [] # Energy cost
    for i in range(N_GENERATIONS):
        fitnessTimePlot.append(data[i].fitness.time) # Tardiness
        fitnessEnergyPlot.append(data[i].fitness.energy) # Energy cost

    fig, ax = plt.subplots(1, 2, figsize=(10, 6))
    ax[0].plot(axisValue, fitnessTimePlot, 'o-', linewidth=2, color='b')
    ax[0].set(xlim=(0, N_GENERATIONS+2), ylim=(0, max(fitnessTimePlot)+2))
    ax[0].set_xlabel('Generation')
    ax[0].set_ylabel('Tardiness (min)')
    ax[0].set_title('Evolution of tardiness')

    ax[1].plot(axisValue, fitnessEnergyPlot, 'o-', linewidth=2, color='r')
    ax[1].set(xlim=(0, N_GENERATIONS+2), ylim=(0, max(fitnessEnergyPlot)+200))
    ax[1].set_xlabel('Generation')
    ax[1].set_ylabel('Energy Cost (€)')
    ax[1].set_title('Evolution of energy cost')

# Creates a permutation list that groups the tasks by job (keeps same index to know which job it is)
# EXAMPLE:
# taskPermutation -> [0, 1, 0, 2, 1, 2, 2]
# Result -> [0, 0, 1, 0, 1, 1, 2] (id of the tasks per job)
def groupByJob(ind):
    result = [] # Result of the grouping
    counterJobs = [] # Id of the task for each job
    for i in range(ind.schedule.nJobs):
        counterJobs.append(0)
    for i in range(ind.schedule.nTasks):
        result.append(counterJobs[ind.tasksPermutation[i]]) # Append the id of the task for each job
        counterJobs[ind.tasksPermutation[i]] += 1 # Increase the id of the task for each job
    
    return result # Return the result of the grouping

# Plot of the best individual schedule
# a -> Instance number
# b -> Iteration number  
def plotSchedule(a, b):
    # Get schedule data
    data = None
    path = os.path.join(r"results/pickel/", f"result_{a}.pkl")
    with open(path, 'rb') as pickled:
        data = pickle.load(pickled) # data is a list of individuals  
        
    # Get individual data
    best = data[b]
    
        
    # Get initial data from the top of the file (fixed positions)
    nJobs = best.schedule.nJobs # Number of jobs
    nMachines = best.schedule.nMachines # Number of machines
    nTasks = best.schedule.nTasks # Number of tasks
    
    y_pos = []
    durations = []
    machine_labels = []
    tasks = []
    start_times = []
    
    # Create plot
    fig, ax = plt.subplots(1, 1, figsize=(10, 6))

    # Group the tasks per job
    tasksByJob = groupByJob(best)


    for i in range(nMachines):
        y_pos.append(i)

    for task in range(nTasks): # Schedule lists are already ordered
        if data.startTimeTasks[task] != -1:                
            start = data.startTimeTasks[task]
            end = data.endTimeTasks[task]
            duration = end - start

            start_times.append(start)
            durations.append(duration)
            indexMachine = best.idPermutation.index(task) # Index for the permutations
            tasks.append(f"J{best.tasksPermutation[indexMachine]}-T{tasksByJob[indexMachine]}")  # Task tag
            machine_labels.append(best.machinePermutation[indexMachine])  # Assigned machine

    for i in range(nTasks):    
        ax[0].barh(machine_labels[i], durations[i], left=start_times[i], 
                    color=colors(machine_labels[i] % nMachines), edgecolor="black")
            
        # Label each task in the middle of the bar
        ax[0].text(start_times[i] + durations[i] / 2, machine_labels[i], tasks[i], 
                va="center", ha="center", color="white")

    # Setting plot info 
    ax[0].set_xlabel("Time (h)")
    ax[0].set_ylabel("Machines")

    # Ensure only the 3 machines appear on the y-axis
    ax[0].set_yticks(range(nMachines))  
    ax[0].set_yticklabels([f"M{i}" for i in range(nMachines)])

    ax[0].set_title("Best Found Schedule")
    ax[0].grid(axis="x", linestyle="--", alpha=0.7)

    plt.show()
